﻿namespace Krusty_Krab
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butReportForm = new System.Windows.Forms.Button();
            this.butEditForm = new System.Windows.Forms.Button();
            this.butAddForm = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // butReportForm
            // 
            this.butReportForm.Font = new System.Drawing.Font("MS Gothic", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butReportForm.Location = new System.Drawing.Point(154, 452);
            this.butReportForm.Name = "butReportForm";
            this.butReportForm.Size = new System.Drawing.Size(456, 92);
            this.butReportForm.TabIndex = 9;
            this.butReportForm.Text = "Reports";
            this.butReportForm.UseVisualStyleBackColor = true;
            this.butReportForm.Click += new System.EventHandler(this.butReportForm_Click);
            // 
            // butEditForm
            // 
            this.butEditForm.Font = new System.Drawing.Font("MS Gothic", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEditForm.Location = new System.Drawing.Point(154, 318);
            this.butEditForm.Name = "butEditForm";
            this.butEditForm.Size = new System.Drawing.Size(456, 92);
            this.butEditForm.TabIndex = 8;
            this.butEditForm.Text = "Edit Information";
            this.butEditForm.UseVisualStyleBackColor = true;
            this.butEditForm.Click += new System.EventHandler(this.butEditForm_Click);
            // 
            // butAddForm
            // 
            this.butAddForm.Font = new System.Drawing.Font("MS Gothic", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAddForm.Location = new System.Drawing.Point(154, 184);
            this.butAddForm.Name = "butAddForm";
            this.butAddForm.Size = new System.Drawing.Size(456, 92);
            this.butAddForm.TabIndex = 7;
            this.butAddForm.Text = "Add Information";
            this.butAddForm.UseVisualStyleBackColor = true;
            this.butAddForm.Click += new System.EventHandler(this.butAddForm_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(219, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 30);
            this.label2.TabIndex = 6;
            this.label2.Text = "Select the following options";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(98, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(586, 43);
            this.label1.TabIndex = 5;
            this.label1.Text = "Welcome to the Krusty Krab Log";
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 593);
            this.Controls.Add(this.butReportForm);
            this.Controls.Add(this.butEditForm);
            this.Controls.Add(this.butAddForm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Welcome";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butReportForm;
        private System.Windows.Forms.Button butEditForm;
        private System.Windows.Forms.Button butAddForm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

