﻿namespace Krusty_Krab
{
    partial class infoAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNotesIn = new System.Windows.Forms.TextBox();
            this.txtDateIn = new System.Windows.Forms.TextBox();
            this.txtNameIn = new System.Windows.Forms.TextBox();
            this.txtSupIn = new System.Windows.Forms.TextBox();
            this.butMenu1 = new System.Windows.Forms.Button();
            this.butAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "Add Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(84, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 30);
            this.label3.TabIndex = 9;
            this.label3.Text = "Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(84, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 30);
            this.label4.TabIndex = 10;
            this.label4.Text = "Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(84, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 30);
            this.label5.TabIndex = 11;
            this.label5.Text = "Supervisor:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(85, 314);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 30);
            this.label6.TabIndex = 12;
            this.label6.Text = "Notes:";
            // 
            // txtNotesIn
            // 
            this.txtNotesIn.Location = new System.Drawing.Point(98, 381);
            this.txtNotesIn.Multiline = true;
            this.txtNotesIn.Name = "txtNotesIn";
            this.txtNotesIn.Size = new System.Drawing.Size(606, 216);
            this.txtNotesIn.TabIndex = 13;
            // 
            // txtDateIn
            // 
            this.txtDateIn.Location = new System.Drawing.Point(240, 99);
            this.txtDateIn.Multiline = true;
            this.txtDateIn.Name = "txtDateIn";
            this.txtDateIn.Size = new System.Drawing.Size(464, 37);
            this.txtDateIn.TabIndex = 15;
            // 
            // txtNameIn
            // 
            this.txtNameIn.Location = new System.Drawing.Point(240, 167);
            this.txtNameIn.Multiline = true;
            this.txtNameIn.Name = "txtNameIn";
            this.txtNameIn.Size = new System.Drawing.Size(464, 37);
            this.txtNameIn.TabIndex = 16;
            // 
            // txtSupIn
            // 
            this.txtSupIn.Location = new System.Drawing.Point(240, 235);
            this.txtSupIn.Multiline = true;
            this.txtSupIn.Name = "txtSupIn";
            this.txtSupIn.Size = new System.Drawing.Size(464, 37);
            this.txtSupIn.TabIndex = 17;
            // 
            // butMenu1
            // 
            this.butMenu1.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMenu1.Location = new System.Drawing.Point(517, 684);
            this.butMenu1.Name = "butMenu1";
            this.butMenu1.Size = new System.Drawing.Size(187, 45);
            this.butMenu1.TabIndex = 18;
            this.butMenu1.Text = "Menu";
            this.butMenu1.UseVisualStyleBackColor = true;
            this.butMenu1.Click += new System.EventHandler(this.butMenu1_Click);
            // 
            // butAdd
            // 
            this.butAdd.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAdd.Location = new System.Drawing.Point(98, 684);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(187, 45);
            this.butAdd.TabIndex = 19;
            this.butAdd.Text = "Add";
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // infoAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 753);
            this.Controls.Add(this.butAdd);
            this.Controls.Add(this.butMenu1);
            this.Controls.Add(this.txtSupIn);
            this.Controls.Add(this.txtNameIn);
            this.Controls.Add(this.txtDateIn);
            this.Controls.Add(this.txtNotesIn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "infoAdd";
            this.Text = "infoAdd";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNotesIn;
        private System.Windows.Forms.TextBox txtDateIn;
        private System.Windows.Forms.TextBox txtNameIn;
        private System.Windows.Forms.TextBox txtSupIn;
        private System.Windows.Forms.Button butMenu1;
        private System.Windows.Forms.Button butAdd;
    }
}