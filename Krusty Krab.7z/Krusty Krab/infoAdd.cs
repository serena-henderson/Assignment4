﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krusty_Krab
{
    public partial class infoAdd : Form
    {
        public infoAdd()
        {
            InitializeComponent();
        }

        //new entity
        private Krusty_KrabEntities dbContext = new Krusty_KrabEntities();
        
        //Process the Add
        private void butAdd_Click(object sender, EventArgs e)
        {
            //create employee object
            Employee employee = new Employee();

            //take the date + error handling
            if (txtDateIn.Text != "")
            {
                employee.Date = txtDateIn.Text;
            }
            else
            {
                MessageBox.Show(this, "Please enter the date", "Date Field Empty",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //take the name + error handling
            if (txtNameIn.Text != "")
            {
                employee.Name = txtNameIn.Text;
            }
            else
            {
                MessageBox.Show(this, "Please enter the name", "Name Field Empty",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //take the supervisor + error handling
            if (txtSupIn.Text != "")
            {
                employee.Supervisor = txtSupIn.Text;
            }
            else
            {
                MessageBox.Show(this, "Please enter the supervisor's name", "Supervisor Field Empty",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //take the notes + error handling
            if (txtNotesIn.Text != "")
            {
                employee.Notes = txtNotesIn.Text;
            }
            else
            {
                MessageBox.Show(this, "Please enter the notes from today", "Notes Field Empty",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //add to database
            dbContext.Employees.Add(employee);

            //save changes
            //dbContext.SaveChanges();
            

            //tell user the information has been saved
            MessageBox.Show(this, employee.Name + ", your information from " +
                employee.Date + " has been saved!", "Employee Saved",
                MessageBoxButtons.OK, MessageBoxIcon.Stop);

            //clear the form
            txtNameIn.Clear();
            txtDateIn.Clear();
            txtSupIn.Clear();
            txtNotesIn.Clear();
        }

        private void butMenu1_Click(object sender, EventArgs e)
        {
            this.Hide();

            //go back to menu
            Form welcome = new Welcome();
            welcome.ShowDialog();

            this.Show();
        }
    }
}
