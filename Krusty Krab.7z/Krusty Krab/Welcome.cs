﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krusty_Krab
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void butAddForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            //open the add information form
            Form infoAdd = new infoAdd();
            infoAdd.ShowDialog();

            this.Show();
        }

        private void butEditForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            //open the edit information form
            Form infoView = new infoView();
            infoView.ShowDialog();

            this.Show();
        }

        private void butReportForm_Click(object sender, EventArgs e)
        {
            this.Hide();

            //open the report form
            Form reporting = new reporting();
            reporting.ShowDialog();

            this.Show();
        }
    }
}
