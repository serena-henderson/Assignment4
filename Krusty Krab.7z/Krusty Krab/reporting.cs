﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krusty_Krab
{
    public partial class reporting : Form
    {
        public reporting()
        {
            InitializeComponent();
        }

        private Krusty_KrabEntities dbContext = new Krusty_KrabEntities();

        private void butSearch_Click(object sender, EventArgs e)
        {
            string name = txtNameSearch.Text;

            if (string.IsNullOrEmpty(name))
                return;

            txtSearchOut.Clear();

            List<Employee> selection = null;

            //if (string.IsNullOrEmpty(name))
            //{

                var employees = from em in dbContext.Employees
                              where em.Name == name
                              orderby em.Name
                              select em;
                 selection = employees.ToList();
            //}

            txtSearchOut.AppendText($"{"ID",-6}" + $"{"Name",-30}" + $"{"Date",-21}" +
                                     $"{"Notes",12}" + Environment.NewLine);

            foreach (var employee in selection)
            {
                txtSearchOut.AppendText($"{employee.ID.ToString(),-7}" + $"{employee.Name,-10}" + 
                                         $"{employee.Date,-20}" + $"{employee.Notes,0}" + Environment.NewLine);
            }
        }

        private void butMenu3_Click(object sender, EventArgs e)
        {
            this.Hide();

            //go back to menu
            Form welcome = new Welcome();
            welcome.ShowDialog();

            this.Show();
        }
    }
}
