﻿namespace Krusty_Krab
{
    partial class reporting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtNameSearch = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSearchOut = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.butSearch = new System.Windows.Forms.Button();
            this.butMenu3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(86, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 30);
            this.label2.TabIndex = 19;
            this.label2.Text = "Reporting";
            // 
            // txtNameSearch
            // 
            this.txtNameSearch.Location = new System.Drawing.Point(242, 104);
            this.txtNameSearch.Multiline = true;
            this.txtNameSearch.Name = "txtNameSearch";
            this.txtNameSearch.Size = new System.Drawing.Size(464, 37);
            this.txtNameSearch.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(86, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 30);
            this.label4.TabIndex = 28;
            this.label4.Text = "Name:";
            // 
            // txtSearchOut
            // 
            this.txtSearchOut.Location = new System.Drawing.Point(100, 284);
            this.txtSearchOut.Multiline = true;
            this.txtSearchOut.Name = "txtSearchOut";
            this.txtSearchOut.Size = new System.Drawing.Size(606, 359);
            this.txtSearchOut.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(86, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 30);
            this.label6.TabIndex = 30;
            this.label6.Text = "Results:";
            // 
            // butSearch
            // 
            this.butSearch.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSearch.Location = new System.Drawing.Point(100, 168);
            this.butSearch.Name = "butSearch";
            this.butSearch.Size = new System.Drawing.Size(606, 45);
            this.butSearch.TabIndex = 33;
            this.butSearch.Text = "Search";
            this.butSearch.UseVisualStyleBackColor = true;
            this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
            // 
            // butMenu3
            // 
            this.butMenu3.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMenu3.Location = new System.Drawing.Point(519, 680);
            this.butMenu3.Name = "butMenu3";
            this.butMenu3.Size = new System.Drawing.Size(187, 45);
            this.butMenu3.TabIndex = 32;
            this.butMenu3.Text = "Menu";
            this.butMenu3.UseVisualStyleBackColor = true;
            this.butMenu3.Click += new System.EventHandler(this.butMenu3_Click);
            // 
            // reporting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 753);
            this.Controls.Add(this.butSearch);
            this.Controls.Add(this.butMenu3);
            this.Controls.Add(this.txtSearchOut);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNameSearch);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Name = "reporting";
            this.Text = "reporting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNameSearch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSearchOut;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button butSearch;
        private System.Windows.Forms.Button butMenu3;
    }
}