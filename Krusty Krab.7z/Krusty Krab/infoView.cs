﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krusty_Krab
{
    public partial class infoView : Form
    {
        public infoView()
        {
            InitializeComponent();
        }

        private Krusty_KrabEntities dbContext = new Krusty_KrabEntities();

        int id = 01;
        //when the next button is clicked, it navigates through the data
        private void butNext_Click(object sender, EventArgs e)
        {
            //increment the id
            id++;
            Employee employee = new Employee();

            List<Employee> selection = null;

            
            txtIdView.Text = id.ToString();

            var employees = from em in dbContext.Employees
                            where em.ID == id
                            orderby em.ID
                            select em;
            selection = employees.ToList();

            //show data associated with the id
            foreach (var employee1 in selection)
            {
                txtDateView.Text = employee1.Date;
                txtNameView.Text = employee1.Name;
                txtSupView.Text = employee1.Supervisor;
                txtNotesView.Text = employee1.Notes;
            }
        }

        private void butBack_Click(object sender, EventArgs e)
        {
            //deincrement the id
            if (id > 0)
                id--;
            Employee employee = new Employee();

            List<Employee> selection = null;


            txtIdView.Text = id.ToString();

            var employees = from em in dbContext.Employees
                            where em.ID == id
                            orderby em.ID
                            select em;
            selection = employees.ToList();

            //show data associated with the id
            foreach (var employee1 in selection)
            {
                txtDateView.Text = employee1.Date;
                txtNameView.Text = employee1.Name;
                txtSupView.Text = employee1.Supervisor;
                txtNotesView.Text = employee1.Notes;
            }
        }

        private void butMenu2_Click(object sender, EventArgs e)
        {
            this.Hide();

            //go back to menu
            Form welcome = new Welcome();
            welcome.ShowDialog();

            this.Show();
        }
    }
}
