﻿namespace Krusty_Krab
{
    partial class infoView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSupView = new System.Windows.Forms.TextBox();
            this.txtNameView = new System.Windows.Forms.TextBox();
            this.txtDateView = new System.Windows.Forms.TextBox();
            this.txtIdView = new System.Windows.Forms.TextBox();
            this.txtNotesView = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.butBack = new System.Windows.Forms.Button();
            this.butMenu2 = new System.Windows.Forms.Button();
            this.butNext = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtSupView
            // 
            this.txtSupView.Location = new System.Drawing.Point(240, 320);
            this.txtSupView.Multiline = true;
            this.txtSupView.Name = "txtSupView";
            this.txtSupView.Size = new System.Drawing.Size(464, 37);
            this.txtSupView.TabIndex = 28;
            // 
            // txtNameView
            // 
            this.txtNameView.Location = new System.Drawing.Point(240, 252);
            this.txtNameView.Multiline = true;
            this.txtNameView.Name = "txtNameView";
            this.txtNameView.Size = new System.Drawing.Size(464, 37);
            this.txtNameView.TabIndex = 27;
            // 
            // txtDateView
            // 
            this.txtDateView.Location = new System.Drawing.Point(240, 184);
            this.txtDateView.Multiline = true;
            this.txtDateView.Name = "txtDateView";
            this.txtDateView.Size = new System.Drawing.Size(464, 37);
            this.txtDateView.TabIndex = 26;
            // 
            // txtIdView
            // 
            this.txtIdView.Location = new System.Drawing.Point(240, 116);
            this.txtIdView.Multiline = true;
            this.txtIdView.Name = "txtIdView";
            this.txtIdView.Size = new System.Drawing.Size(464, 37);
            this.txtIdView.TabIndex = 25;
            // 
            // txtNotesView
            // 
            this.txtNotesView.Location = new System.Drawing.Point(98, 445);
            this.txtNotesView.Multiline = true;
            this.txtNotesView.Name = "txtNotesView";
            this.txtNotesView.Size = new System.Drawing.Size(606, 216);
            this.txtNotesView.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(84, 395);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 30);
            this.label6.TabIndex = 23;
            this.label6.Text = "Notes:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(84, 323);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 30);
            this.label5.TabIndex = 22;
            this.label5.Text = "Supervisor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(84, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 30);
            this.label4.TabIndex = 21;
            this.label4.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(84, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 30);
            this.label3.TabIndex = 20;
            this.label3.Text = "Date:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 30);
            this.label1.TabIndex = 19;
            this.label1.Text = "ID: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 30);
            this.label2.TabIndex = 18;
            this.label2.Text = "Edit Information";
            // 
            // butBack
            // 
            this.butBack.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butBack.Location = new System.Drawing.Point(98, 685);
            this.butBack.Name = "butBack";
            this.butBack.Size = new System.Drawing.Size(187, 45);
            this.butBack.TabIndex = 30;
            this.butBack.Text = "Back";
            this.butBack.UseVisualStyleBackColor = true;
            this.butBack.Click += new System.EventHandler(this.butBack_Click);
            // 
            // butMenu2
            // 
            this.butMenu2.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMenu2.Location = new System.Drawing.Point(517, 685);
            this.butMenu2.Name = "butMenu2";
            this.butMenu2.Size = new System.Drawing.Size(187, 45);
            this.butMenu2.TabIndex = 29;
            this.butMenu2.Text = "Menu";
            this.butMenu2.UseVisualStyleBackColor = true;
            this.butMenu2.Click += new System.EventHandler(this.butMenu2_Click);
            // 
            // butNext
            // 
            this.butNext.Font = new System.Drawing.Font("MS Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butNext.Location = new System.Drawing.Point(310, 685);
            this.butNext.Name = "butNext";
            this.butNext.Size = new System.Drawing.Size(187, 45);
            this.butNext.TabIndex = 31;
            this.butNext.Text = "Next";
            this.butNext.UseVisualStyleBackColor = true;
            this.butNext.Click += new System.EventHandler(this.butNext_Click);
            // 
            // infoView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 753);
            this.Controls.Add(this.butNext);
            this.Controls.Add(this.butBack);
            this.Controls.Add(this.butMenu2);
            this.Controls.Add(this.txtSupView);
            this.Controls.Add(this.txtNameView);
            this.Controls.Add(this.txtDateView);
            this.Controls.Add(this.txtIdView);
            this.Controls.Add(this.txtNotesView);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Name = "infoView";
            this.Text = "infoView";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSupView;
        private System.Windows.Forms.TextBox txtNameView;
        private System.Windows.Forms.TextBox txtDateView;
        private System.Windows.Forms.TextBox txtIdView;
        private System.Windows.Forms.TextBox txtNotesView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button butBack;
        private System.Windows.Forms.Button butMenu2;
        private System.Windows.Forms.Button butNext;
    }
}